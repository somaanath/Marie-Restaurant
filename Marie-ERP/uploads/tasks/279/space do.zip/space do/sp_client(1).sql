-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2021 at 04:58 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sparesdo`
--

-- --------------------------------------------------------

--
-- Table structure for table `sp_client`
--

CREATE TABLE `sp_client` (
  `id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `alternate_mobile` varchar(20) NOT NULL,
  `state` varchar(60) NOT NULL,
  `district` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `client_image` text NOT NULL,
  `remarks` text NOT NULL,
  `vehiclebrand` varchar(20) NOT NULL,
  `vehiclemodel` varchar(20) NOT NULL,
  `vehicleyear` varchar(20) NOT NULL,
  `vehiclevarient` varchar(20) NOT NULL,
  `vehicleremarks` varchar(20) NOT NULL,
  `vehiclechecklist_id` varchar(20) NOT NULL,
  `vehicledamage_reportid` varchar(20) NOT NULL,
  `vehicleinspection_reportid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sp_client`
--

INSERT INTO `sp_client` (`id`, `name`, `mobile`, `alternate_mobile`, `state`, `district`, `city`, `client_image`, `remarks`, `vehiclebrand`, `vehiclemodel`, `vehicleyear`, `vehiclevarient`, `vehicleremarks`, `vehiclechecklist_id`, `vehicledamage_reportid`, `vehicleinspection_reportid`) VALUES
(5, 'dsfasadf', '4634646436', '6436436436', 'Andhra Pradesh', 'Chittoor', 'Adaram', 'images/clients/55b627e70c22afb7d0d22fd6fd46f1a1.jpg', '1234', 'Hero', '2021', 'M1999', 'Red', 'No', '10001', 'R0001', 'Ine001'),
(6, 'fasdf', '876868', '786786768', 'Andhra Pradesh', 'Cuddapah', 'Abbavaram', 'images/clients/1edbf8f0da164c03f455aa54d3dd0116.jpg', 'gtgfdghsf', 'Hero', '2021', '', '', '', '', '', ''),
(7, 'fgsfg', '76767464', '6786786', 'Delhi', 'East Delhi', 'Babarpur', 'images/clients/3e9598a00a6803b3fe4d1ad0b5257f9e.jpg', 'dgsdfgsdf', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(8, 'farfa', '674744', '674687468468', 'Andhra Pradesh', 'Cuddapah', 'Abbavaram', 'images/clients/83d8c552f192eebf5a8612bbe8b81a01.jpg', 'rreqwrqer', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(9, 'sdfads', '7867887', '78877867', 'Andhra Pradesh', 'Chittoor', 'Adaram', 'images/clients/8fabcd5ef90e2681ad2b6650d03ecbc4.jpg', 'asada', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(10, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/4fec5720112411afa7a3a544ee433546.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(11, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/ce41dd5b4278ca25d09a5650a3a4ceb8.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(12, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/716d91aa24ca3b53b46b6a69caf0eea8.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(13, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/e883db216dfd223cfbf92642e2431a85.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', '', '', '', ''),
(14, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/25652183f7f47db17c1bcd6fbca21947.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', 'No', '10001', '', ''),
(15, 'dscfsafd', '876876868768687', '98798798798', 'Haryana', 'Faridabad', 'Alawalpur', 'images/clients/1c0a160203ac25dde010d1ff35a4c462.jpg', 'fdsadfdas', 'Hero', '2021', 'M1999', 'Red', 'No', '10001', 'R0001', ''),
(16, 'dsfasdfa', '42342346', '6474764', 'Andhra Pradesh', 'Anantapur', 'A Narayana', 'images/clients/ecfe02d8493066bf17b3e24610eae99c.jpg', 'wewqrew', 'Hero', '2021', 'M1999', 'Red', 'No', '10001', 'R0001', 'Ine001'),
(17, 'sdafas', '767846877846', '6867868', 'Andhra Pradesh', 'East Godav', 'A Mallavar', 'images/clients/2507dad5ed2a7b1f3781756fddf26e52.jpg', 'fasdgfa', '1', '1', '1', '10299', 'dfadsfa', '10001', 'R0001', 'Ine001'),
(18, 'xvzx', '67676767', '332434', 'Delhi', 'Central De', 'A.K.market', 'images/clients/828b085f45641691b09d595a12aa4366.jpg', 'dsfsdf', '2', '73', '504', '790', 'ddsdf', '10001', 'R0001', 'Ine001'),
(19, 'dcfasf', '637676', '78686786', 'Haryana', 'Bhiwani', 'Choose Loc', 'images/clients/d0fc556a7507284c2dd58709ded66815.jpg', 'dfadsfadsf', 'Hero', '2021', 'M1999', 'Red', 'Noooo...', '10001', 'R0001', 'Ine001');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sp_client`
--
ALTER TABLE `sp_client`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sp_client`
--
ALTER TABLE `sp_client`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
