<?php 
include("../config.php");
if( isset($_POST['action']) && !empty($_POST['action']) )
{
  $action = $_POST['action'];
	switch($action)
	{
		case 'edit_car_make':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $make_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_car_make where make_id='".$make_id."' Limit 1");
		   ?>

			<div id="priority_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Priority <span class="redstar">*</span></span>
	          <input name="priority" id="priority" required="" class="form-control" placeholder="Priority" type="text" value="<?= $result_data['priority']; ?>"/>
	        </div>
	        <div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Make <span class="redstar">*</span></span>
	          <input name="make" id="make" required="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make']; ?>"/>
	        </div>
	        <div id="vehicle_make_image" class="col-md-12 top15">
	          <span class="badge-label p-2">Make Image <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['make_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="make_image1" style="margin-top: 10px;" />
	        </div>
	        <input name="make_image" id="make_image" hidden="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make_image']; ?>"/>	        
	        <input name="make_id" id="make_id" hidden="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_car_model':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $model_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_car_model where model_id='".$model_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Model <span class="redstar">*</span></span>
	          <input name="model" id="model" required="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model']; ?>"/>
	        </div>
	        <div id="vehicle_make_image" class="col-md-12 top15">
	          <span class="badge-label p-2">Model Image <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['model_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="model_image1" style="margin-top: 10px;" />
	        </div>
	        <input name="model_image" id="model_image" hidden="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model_image']; ?>"/>	        
	        <input name="model_id" id="model_id" hidden="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_car_year':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $year_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_car_year where year_id='".$year_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Year <span class="redstar">*</span></span>
	          <input name="year" id="year" required="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['year']; ?>"/>
	        </div>
	        
	        <input name="year_id" id="year_id" hidden="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['year_id']; ?>"/>
			<?php 
			}
			break;
		}

		case 'edit_car_variant':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $variant_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_car_variant where variant_id='".$variant_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Variant <span class="redstar">*</span></span>
	          <input name="variant" id="variant" required="" class="form-control" placeholder="Vehicle Variant" type="text" value="<?= $result_data['variant']; ?>"/>
	        </div>
	        
	        <input name="variant_id" id="variant_id" hidden="" class="form-control" placeholder="Vehicle Variant" type="text" value="<?= $result_data['variant_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_bike_make':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $make_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_bike_make where make_id='".$make_id."' Limit 1");
		   ?>
		   	<div id="priority_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Priority <span class="redstar">*</span></span>
	          <input name="priority" id="priority" required="" class="form-control" placeholder="Priority" type="text" value="<?= $result_data['priority']; ?>"/>
	        </div>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Make <span class="redstar">*</span></span>
	          <input name="make" id="make" required="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make']; ?>"/>
	        </div>
	        <div id="vehicle_make_image" class="col-md-12 top15">
	          <span class="badge-label p-2">Make Image <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['make_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="make_image1" style="margin-top: 10px;" />
	        </div>
	        <input name="make_image" id="make_image" hidden="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make_image']; ?>"/>	        
	        <input name="make_id" id="make_id" hidden="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['make_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_bike_model':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $model_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_bike_model where model_id='".$model_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Model <span class="redstar">*</span></span>
	          <input name="model" id="model" required="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model']; ?>"/>
	        </div>
	        <div id="vehicle_make_image" class="col-md-12 top15">
	          <span class="badge-label p-2">Model Image <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['model_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="model_image1" style="margin-top: 10px;" />
	        </div>
	        <input name="model_image" id="model_image" hidden="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model_image']; ?>"/>	        
	        <input name="model_id" id="model_id" hidden="" class="form-control" placeholder="Vehicle Model" type="text" value="<?= $result_data['model_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_bike_year':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $year_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_bike_year where year_id='".$year_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Year <span class="redstar">*</span></span>
	          <input name="year" id="year" required="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['year']; ?>"/>
	        </div>
	        
	        <input name="year_id" id="year_id" hidden="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['year_id']; ?>"/>
			<?php 
			}
			break;
		}

		case 'edit_bike_variant':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $variant_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_bike_variant where variant_id='".$variant_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Variant <span class="redstar">*</span></span>
	          <input name="variant" id="variant" required="" class="form-control" placeholder="Vehicle Variant" type="text" value="<?= $result_data['variant']; ?>"/>
	        </div>
	        
	        <input name="variant_id" id="variant_id" hidden="" class="form-control" placeholder="Vehicle Variant" type="text" value="<?= $result_data['variant_id']; ?>"/>
			<?php 
			}
			break;
		}
		case 'edit_popularlocation':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $popular_location_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_popular_locations where popular_location_id='".$popular_location_id."' Limit 1");
			?>
			<div id="vehicle_make" class="col-md-12 top15">
	          <span class="badge-label p-2">Popular Locations <span class="redstar">*</span></span>
	          <input name="popularlocation" id="popularlocation" required="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['location']; ?>"/>
	        </div>
	        
	        <input name="popular_location_id" id="popular_location_id" hidden="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['popular_location_id']; ?>"/>
			<?php 
			}
			break;
		}

		case 'edit_popularlocation_state':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $state_location_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_popular_locations_state where state_location_id='".$state_location_id."' Limit 1");
			?>

			<div class="col-md-12 top15">
                        <span class="badge-label info-color p-2">State<span class="redstar">*</span></span>                        
                        <select name="state" id="state1" class="select2" required="">
                          <option value="">Choose State</option>
                          <?php 
                          $options = $db->getRows("Select state from sp_locations group by state order by state");
                          if(count($options)>0){
                          foreach ($options as $key => $value) {
                          ?>
                          <option <?php if($result_data["state"]==$value["state"]){echo "selected";} ?> ><?=$value["state"]?></option>
                          <?php } } ?>
                        </select>
                      </div>

			<div id="popular_locations" class="col-md-12 top15">
	          <span class="badge-label p-2">Popular Locations <span class="redstar">*</span></span>
	          <input name="popularlocation" id="popularlocation" required="" class="form-control" placeholder="Popular Locations" type="text" value="<?= $result_data['district']; ?>"/>
	        </div>
	        
	        <input name="state_location_id" id="state_location_id" hidden="" class="form-control" placeholder="Vehicle Year" type="text" value="<?= $result_data['state_location_id']; ?>"/>
			<?php 
			}
			break;
		}

case 'edit_location':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $location_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_locations where location_id='".$location_id."' Limit 1");
			
        	$state = $result_data['state'];
        	$location = $result_data['location'];
        	$district = $result_data['district'];
        	$pincode = $result_data['pincode'];

			?>
			<div class="col-md-12 top15">
	          <span class="badge-label p-2">State <span class="redstar">*</span></span>
	            <select name="state" id="state1" class="select2" required="">
                  <?php 
                  $options = $db->getRows("Select state from sp_locations group by state order by state");
                  if(count($options)>0){?>
                   <option>Choose State</option>
                  <?php foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['state']==$value["state"]){ echo "selected"; } ?> ><?=$value["state"]?></option>
                  <?php } } ?>
                </select>
	        </div>

	        <div class="col-md-12 top15">
          	    <span class="badge-label info-color p-2">District<span class="redstar">*</span></span>
                    <select name="district" id="district1" class="select2" required="">
                    <?php 
                  $options = $db->getRows("Select district from sp_locations where state='$state' group by district order by district");
                  if(count($options)>0){ ?>
                   <option>Choose District</option>
                   <?php
                  foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['district']==$value["district"]){ echo "selected"; } ?> ><?=$value["district"]?></option>
                  <?php } } ?>
                </select>
	        </div>
	        
            <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Location<span class="redstar">*</span></span>
                <select name="location" id="location1" class="select2" required="">
                  <?php 
                  $options = $db->getRows("Select location from sp_locations where state='$state' and district ='$district' group by location order by location");
                  if(count($options)>0){?>
                   <option>Choose Location</option>
                   <?php
                  foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['location']==$value["location"]){ echo "selected"; } ?> ><?=$value["location"]?></option>
                  <?php } } ?>
                </select>
            </div>
                      
            <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Pincode<span class="redstar">*</span></span>
                <input type="text" name="pincode" id="pincode1" class="form-control" value="<?=$pincode?>">
		    </div>

	        <input name="location_id" id="location_id" hidden="" class="form-control" placeholder="" type="text" value="<?= $result_data['location_id']; ?>"/>
			<?php 
			}
			break;
		}
		
		case 'get_vehicletype':{
			if(isset($_POST["vehicletype"])){
				$vehicletype = $_POST["vehicletype"];
				
				if($vehicletype == "bike")
				{
				$Details = $db->getRows("SELECT make_id, make FROM sp_bike_make order by make_id");
				}
				else if($vehicletype == "car")
				{
				$Details = $db->getRows("SELECT make_id, make FROM sp_car_make order by make_id");
				
				}
				
				
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';
						
			$districts='<option value="">Choose Vehicle Brand</option>';
						foreach ($Details as $key => $value) {
							$district = $value["make"];
							$districtid = $value["make_id"];
							$districts.="<option value=".$districtid.">".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}		
		
		case 'get_vehiclebrand':{
			if(isset($_POST["vehiclebrand"])){
				$vehiclebrand = $_POST["vehiclebrand"];
				$vehicletype = $_POST["vehicletype"];

				if($vehicletype == "bike")
				{
				$Details = $db->getRows("SELECT model_id, model FROM sp_bike_model where make_id='$vehiclebrand' order by model_id");
				}
				else if($vehicletype == "car")
				{
				$Details = $db->getRows("SELECT model_id, model FROM sp_car_model where make_id='$vehiclebrand' order by model_id");
				
				}
				
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';
						
				$districts='<option value="">Choose Vehicle Model</option>';
						
						foreach ($Details as $key => $value) {
							$district = $value["model"];
							$districtid = $value["model_id"];
							$districts.="<option value=".$districtid.">".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}		
		
		case 'get_vehiclemodel':{
			if(isset($_POST["vehiclemodel"])){
				$vehiclemodel = $_POST["vehiclemodel"];
				$vehicletype = $_POST["vehicletype"];

				if($vehicletype == "bike")
				{
				$Details = $db->getRows("SELECT year_id, year FROM sp_bike_year where model_id='$vehiclemodel' order by year_id");
				}
				else if($vehicletype == "car")
				{
				$Details = $db->getRows("SELECT year_id, year FROM sp_car_year where model_id='$vehiclemodel' order by year_id");
				
				}
				
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';
						
				$districts='<option value="">Choose Vehicle Year</option>';
						
						foreach ($Details as $key => $value) {
							$district = $value["year"];
							$districtid = $value["year_id"];
							$districts.="<option value=".$districtid.">".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}		
		

		case 'get_vehicleyear':{
			if(isset($_POST["vehicleyear"])){
				$vehicleyear = $_POST["vehicleyear"];
				$vehicletype = $_POST["vehicletype"];

				if($vehicletype == "bike")
				{
				$Details = $db->getRows("SELECT variant_id, variant FROM sp_bike_variant where year_id='$vehicleyear' order by variant_id");
				}
				else if($vehicletype == "car")
				{
				$Details = $db->getRows("SELECT variant_id, variant FROM sp_car_variant where year_id='$vehicleyear' order by variant_id");
				
				}
				
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';
						
				$districts='<option value="">Choose Vehicle Year</option>';
						
						foreach ($Details as $key => $value) {
							$district = $value["variant"];
							$districtid = $value["variant_id"];
							$districts.="<option value=".$districtid.">".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}		

		
		
		
		

		case 'get_district':{
			if(isset($_POST["state"])){
				$state = $_POST["state"];
				$Details = $db->getRows("SELECT district FROM sp_locations where state='$state' group by district order by district");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$districts='<option value="">Choose District</option>';
						foreach ($Details as $key => $value) {
							$district = $value["district"];
							$districts.="<option>".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}

		case 'get_location':{
			if(isset($_POST["state"]) && isset($_POST["district"])){
				$state = $_POST["state"];
				$district = $_POST["district"];
				$Details = $db->getRows("SELECT location FROM sp_locations where state='$state' and district='$district' group by location order by location");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$locations='<option value="">Choose Location</option>';
						foreach ($Details as $key => $value) {
							$location = $value["location"];
							$locations.="<option>".$location."</option>";
						}
						$arrResult1['Data']=$locations;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}
		case 'get_pincode':{
			if(isset($_POST["state"]) && isset($_POST["district"]) && isset($_POST["location"])){
			 	$state = $_POST["state"];
				$district = $_POST["district"];
				$location = $_POST["location"];
				$Details = $db->getRows("SELECT pincode FROM sp_locations where state='$state' and district='$district' and location='$location' group by pincode order by pincode");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$pincodes='<option value="">Choose Pincode</option>';
						foreach ($Details as $key => $value) {
							$pincode = $value["pincode"];
							$pincodes.="<option>".$pincode."</option>";
						}
						$arrResult1['Data']=$pincodes;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;

			}
			break;
		}


		case 'get_buyer_district':{
			if(isset($_POST["state"])){
				$state = $_POST["state"];
				$Details = $db->getRows("SELECT district FROM sp_buyer_locations where state='$state' group by district order by district");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$districts='<option value="">Choose District</option>';
						foreach ($Details as $key => $value) {
							$district = $value["district"];
							$districts.="<option>".$district."</option>";
						}
						$arrResult1['Data']=$districts;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}

		case 'get_buyer_location':{
			if(isset($_POST["state"]) && isset($_POST["district"])){
				$state = $_POST["state"];
				$district = $_POST["district"];
				$Details = $db->getRows("SELECT location FROM sp_buyer_locations where state='$state' and district='$district' group by location order by location");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$locations='<option value="">Choose Location</option>';
						foreach ($Details as $key => $value) {
							$location = $value["location"];
							$locations.="<option>".$location."</option>";
						}
						$arrResult1['Data']=$locations;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;
			}
			break;
		}
		case 'get_buyer_pincode':{
			if(isset($_POST["state"]) && isset($_POST["district"]) && isset($_POST["location"])){
			 	$state = $_POST["state"];
				$district = $_POST["district"];
				$location = $_POST["location"];
				$Details = $db->getRows("SELECT pincode FROM sp_buyer_locations where state='$state' and district='$district' and location='$location' group by pincode order by pincode");	
				if (count($Details) > 0) {
						$arrResult1['status'] = 'success'; 
						$arrResult1['code'] = 200; 			
						$arrResult1['Data'] = '';$pincodes='<option value="">Choose Pincode</option>';
						foreach ($Details as $key => $value) {
							$pincode = $value["pincode"];
							$pincodes.="<option>".$pincode."</option>";
						}
						$arrResult1['Data']=$pincodes;
				}
					else{
						$arrResult1['status'] = 'error'; 
						$arrResult1['code'] = 201; 				
						$arrResult1['message'] = 'No Data Found !';				
					}
				echo json_encode($arrResult1);
				exit;

			}
			break;
		}

		case 'edit_content':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $content_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_content where content_id='".$content_id."' Limit 1");
        	$section = $result_data['section'];
        	$content = $result_data['content'];

			?>
            <h5 class="text-center"><?=$section?></h5>
            <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Content</span><br/>
                <textarea id="content" name="content"><?=$content?></textarea>
		    </div>

	        <input name="content_id" id="content_id" hidden="" class="form-control" placeholder="" type="text" value="<?= $result_data['content_id']; ?>"/>
			<?php 
			}
			break;
		}

		case 'edit_subadmin':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $sb_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_subadmin where sb_id='".$sb_id."' Limit 1");
        	$name = $result_data['name'];
        	$mobile = $result_data['mobile'];
        	$email = $result_data['email'];
        	$address = $result_data['address'];
        	$username = $result_data['username'];
        	$password = $result_data['password'];
			?>
             <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Name<span class="redstar">*</span></span>
                <input type="text" id="sub_name1" name="sub_name" class="form-control" placeholder="Name" value="<?=$name?>" required="">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Mobile<span class="redstar">*</span></span>
                <input type="number" id="sub_mobile1" name="sub_mobile" class="form-control" placeholder="Mobile" value="<?=$mobile?>" required="">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Email</span><br/>
                         <input type="email" id="sub_email1" name="sub_email" class="form-control" placeholder="Email" value="<?=$email?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Address</span><br/>
                 <textarea id="sub_address1" name="sub_address" class="form-control" placeholder="Address"><?=$address?></textarea>
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Username<span class="redstar">*</span></span><br/>
                         <input type="text" id="sub_username1" name="sub_username" class="form-control" placeholder="Username" value="<?=$username?>" required="">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label info-color p-2">Password<span class="redstar">*</span></span><br/>
                <input type="password" id="sub_password1" name="sub_password" class="form-control" placeholder="Password" value="<?=$password?>" required="">
              </div>

	        <input name="sb_id" id="sb_id" hidden="" class="form-control" placeholder="" type="text" value="<?= $result_data['sb_id']; ?>"/>
			<?php 
			}
			break;
		}

case 'edit_client':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $make_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_client where id='".$make_id."' Limit 1");
	
        	$state = $result_data['state'];
        	$location = $result_data['city'];
        	$district = $result_data['district'];
	?>

					  <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Name<span class="redstar">*</span></span>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Name" value="<?= $result_data['name']; ?>" required="">
                      </div>

			              <div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Mobile<span class="redstar">*</span></span>
		                    <input type="text" id="mobile" name="mobile" class="form-control" placeholder="Mobile" value="<?= $result_data['mobile']; ?>" required="">
		              </div>		
			
						<div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Alternate Mobile<span class="redstar">*</span></span>
		                    <input type="text" id="alternate_mobile" name="alternate_mobile" class="form-control" placeholder="Alternate Mobile" value="<?= $result_data['alternate_mobile']; ?>" required="">
		              </div>
			
			<div class="col-md-6 top15">
	          <span class="badge-label p-2">State <span class="redstar">*</span></span>
	            <select name="state" id="state1" class="select2" required="">
                  <?php 
                  $options = $db->getRows("Select state from sp_locations group by state order by state");
                  if(count($options)>0){?>
                   <option>Choose State</option>
                  <?php foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['state']==$value["state"]){ echo "selected"; } ?> ><?=$value["state"]?></option>
                  <?php } } ?>
                </select>
	        </div>					  
	
	        <div class="col-md-6 top15">
          	    <span class="badge-label info-color p-2">District<span class="redstar">*</span></span>
                    <select name="district" id="district1" class="select2" required="">
                    <?php 
                  $options = $db->getRows("Select district from sp_locations where state='$state' group by district order by district");
                  if(count($options)>0){ ?>
                   <option>Choose District</option>
                   <?php
                  foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['district']==$value["district"]){ echo "selected"; } ?> ><?=$value["district"]?></option>
                  <?php } } ?>
                </select>
	        </div>
	        
            <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Location<span class="redstar">*</span></span>
                <select name="location" id="location1" class="select2" required="">
                  <?php 
                  $options = $db->getRows("Select location from sp_locations where state='$state' and district ='$district' group by location order by location");
                  if(count($options)>0){?>
                   <option>Choose Location</option>
                   <?php
                  foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['city']==$value["location"]){ echo "selected"; } ?> ><?=$value["location"]?></option>
                  <?php } } ?>
                </select>
            </div>
	
	        <div id="vehicle_make_image" class="col-md-6 top15">
	          <span class="badge-label p-2">Client Image <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['client_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="make_image1" style="margin-top: 10px;" />
	        </div>
	        <input name="client_image" id="client_image" hidden="" class="form-control" placeholder="Vehicle Make" type="text" value="<?= $result_data['client_image']; ?>"/>	


					  <div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Remarks<span class="redstar">*</span></span>
		                    <input type="text" id="remarks" name="remarks" class="form-control" placeholder="Remarks" value="<?= $result_data['remarks']; ?>" required="">
		              </div>
					  
					    <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Vehicle Brand<span class="redstar">*</span></span>

                        <select name="vehiclebrand" id="vehiclebrand" class="select2" required="">
                          <option value="">Please Choose Vehicle Brand</option>
                          <option value="Hero">Hero</option>
                        </select>
                      </div>
					  
					  					    <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Vehicle Model<span class="redstar">*</span></span>

                        <select name="vehiclemodel" id="vehiclemodel" class="select2" required="">
                          <option value="">Please Choose Vehicle Model </option>
                          <option value="2021">2021</option>
                        </select>
                      </div>
					  
         <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Vehicle Year<span class="redstar">*</span></span>

                        <select name="vehicleyear" id="vehicleyear" class="select2" required="">
                          <option value="">Please Choose Vehicle Year</option>
                          <option value="M1999">M1999</option>
                        </select>
                      </div>
					  
					  					  			  					    <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Vehicle Varient <span class="redstar">*</span></span>

                        <select name="vehiclevarient" id="vehiclevarient" class="select2" required="">
                          <option value="">Please Choose Vehicle Varient </option>
                          <option value="Red">Red</option>
                        </select>
                      </div>
					  
					  
					  <div class="col-md-6 top15">
                        <span class="badge-label info-color p-2">Vehicle Remarks  <span class="redstar">*</span></span>

		                    <input type="text" id="vehicleremarks" name="vehicleremarks" class="form-control" placeholder="Vehicle Remarks" value="<?= $result_data['vehicleremarks']; ?>" required="">


                      </div>
					  
					  

<div class="row" style="clear: both;">
					   					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	Vehicle Checklist ID  <span class="redstar">*</span></span>

                        <select name="vehiclechecklist_id" id="vehiclechecklist_id" class="select2" required="">
                          <option value="">Please Choose Vehicle Checklist</option>
                          <option value="10001">10001</option>
                        </select>
                      </div>
					   
		
		<div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	Vehicle Damage Report ID<span class="redstar">*</span></span>

                        <select name="vehicledamage_reportid" id="vehicledamage_reportid" class="select2" required="">
                          <option value="">Please Choose Vehicle Damage Reportid</option>
                          <option value="R0001">R0001</option>
                        </select>
                      </div>

					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	 	Vehicle Inspection Report ID<span class="redstar">*</span></span>

        <select name="vehicleinspectionreportid" id="vehicleinspection_reportid" class="select2" required="">
                          <option value="">Please Choose  	Vehicle Inspection Report ID</option>
                          <option value="Ine001">Ine001</option>
                        </select>
                      </div>

</div>
			
	        <input name="edit_id" id="edit_id" hidden="" class="form-control" placeholder="Client id" type="text" value="<?= $result_data['id']; ?>"/>
			<?php 
			}
			break;
		}
	
		case 'edit_station':{ 		
		  	if( isset($_POST['id']) && !empty($_POST['id']) )
	      	{
	        
	        $sb_id = $_POST['id'];
        	$result_data = $db->getRow("select * from sp_station_name where  station_id='".$sb_id."' Limit 1");
			
        	$name = $result_data['station_name'];
        	$mobile = $result_data['mobile'];
        	$alternate_mobile = $result_data['alternate_mobile'];
        	$email = $result_data['email'];
        	$contact_person = $result_data['contact_person'];
        	$address = $result_data['address'];
        	$latitude = $result_data['latitude'];
        	$longitude = $result_data['longitude'];
			
            $state = $result_data['state'];
        	$district = $result_data['district'];

			?>
             <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Station Name<span class="redstar">*</span></span>
                <input type="text" id="name1" name="name" class="form-control" placeholder="Name" value="<?=$name?>" required="">
              </div>
			  
              <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Mobile<span class="redstar">*</span></span>
                <input type="number" id="mobile" name="mobile" class="form-control" placeholder="Mobile" value="<?=$mobile?>" required="">
              </div>
			  
			                <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Alternate Mobile<span class="redstar">*</span></span>
                <input type="number" id="alternate_mobile" name="alternate_mobile" class="form-control" placeholder="Mobile" value="<?=$alternate_mobile?>" required="">
              </div>
			  
			  
			  
              <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Email</span><br/>
                         <input type="email" id="email_id1" name="email_id" class="form-control" placeholder="Email" value="<?=$email?>">
              </div>

					  <div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Contact Person<span class="redstar">*</span></span>
		                    <input type="text" id="contact_person" name="contact_person" class="form-control" placeholder="Contact Person Name" value="<?=$contact_person?>" required="">
		              </div>

	        <div id="station_make_image" class="col-md-6 top15">
	          <span class="badge-label p-2">Station Photo <span class="redstar">*</span></span><br/>  
	          <img src="../<?= $result_data['station_image']; ?>" style="max-width: 70px">       
	          <input  type="file" name="station_image" style="margin-top: 10px;" />
	        </div>
	        <input name="station_image1" id="station_image1" hidden="" class="form-control" placeholder="station image" type="text" value="<?= $result_data['station_image']; ?>"/>

			  
              <div class="col-md-6 top15">
                <span class="badge-label info-color p-2">Address</span><br/>
                 <textarea id="address1" name="address" class="form-control" placeholder="Address"><?=$address?></textarea>
              </div>
			  

			<div class="col-md-6 top15">
	          <span class="badge-label p-2">State <span class="redstar">*</span></span>
	            <select name="state" id="state1" class="select2" required="">
                  <?php 
                  $options = $db->getRows("Select state from sp_locations group by state order by state");
                  if(count($options)>0){?>
                   <option>Choose State</option>
                  <?php foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['state']==$value["state"]){ echo "selected"; } ?> ><?=$value["state"]?></option>
                  <?php } } ?>
                </select>
	        </div>					  
	
	        <div class="col-md-6 top15">
          	    <span class="badge-label info-color p-2">District<span class="redstar">*</span></span>
                    <select name="district" id="district1" class="select2" required="">
                    <?php 
                  $options = $db->getRows("Select district from sp_locations where state='$state' group by district order by district");
                  if(count($options)>0){ ?>
                   <option>Choose District</option>
                   <?php
                  foreach ($options as $key => $value) {
                  ?>
                  <option <?php if($result_data['district']==$value["district"]){ echo "selected"; } ?> ><?=$value["district"]?></option>
                  <?php } } ?>
                </select>
	        </div>


					  <div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Latitude<span class="redstar">*</span></span>
		                    <input type="text" id="latitude" name="latitude" class="form-control" placeholder="Latitude" value="<?=$latitude?>" required="">
		              </div>
					  
					  					  <div class="col-md-6 top15">
		                    <span class="badge-label info-color p-2">Longitude<span class="redstar">*</span></span>
		                    <input type="text" id="longitude" name="longitude" class="form-control" placeholder="Longitude" value="<?=$longitude?>" required="">
		              </div>


	        <input name="edit_id" id="edit_id" hidden="" class="form-control" placeholder="" type="text" value="<?= $result_data['station_id']; ?>"/>
			<?php 
			}
			break;
		}		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
}
?>