<?php include 'inc-meta.php'; ?>
</head>
<body>
<!--------------------->
<div id="wrapper">
    <?php include 'inc_leftmenubar.php'; ?>
	<div id="page-wrapper">
		<div class="container-fluid">
	        <div class="row panel panel-default page-wrapper-panel">
		        <div class="gradient-card-header">
		            <h2 class="white-text mx-3">Client</h2>
		        </div>
				<div class="sp_add">
				    <button id="add_form" class="btn btn-info button-addnew pull-right" data-toggle="collapse" data-target="#add_client" ><i class="fa fa-plus-circle" aria-hidden="true"></i>Add New <i class="fa fa-angle-down" aria-hidden="true"></i></button>
		            <br/><br/>

		            <div id="add_client" class="panel panel-default collapse">
		              <div class="panel-body">
					  
		                <form method="post" id="client_add"   enctype="multipart/form-data">
                      
					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Name<span class="redstar">*</span></span>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Name" value="" required="">
                      </div>
					  
		              <div class="col-md-4 top15">
		                    <span class="badge-label info-color p-2">Mobile<span class="redstar">*</span></span>
		                    <input type="text" id="mobile" name="mobile" class="form-control" placeholder="Mobile" value="" required="">
		              </div>
		               
					   <div class="col-md-4 top15">
		                    <span class="badge-label info-color p-2">Alternate Mobile<span class="redstar">*</span></span>
		                    <input type="text" id="alternate_mobile" name="alternate_mobile" class="form-control" placeholder="Alternate Mobile" value="" required="">
		              </div>
					   
		            <div class="col-md-4 top15">
		                    <span class="badge-label info-color p-2">State<span class="redstar">*</span></span>		                    
	                        <select name="state" id="state" class="select2" required="">
	                          <option value="">Choose State</option>
	                          <?php 
	                          $options = $db->getRows("Select state from sp_buyer_locations group by state order by state");
	                          if(count($options)>0){
	                          foreach ($options as $key => $value) {
	                          ?>
	                          <option><?=$value["state"]?></option>
	                          <?php } } ?>
	                        </select>
                      </div>					   
					   
					   <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">District<span class="redstar">*</span></span>

                        <select name="district" id="district" class="select2" required="">
                          <option value="">Please Choose State</option>
                        </select>
                      </div>   
					   
					   
                         <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Location<span class="redstar">*</span></span>

                        <select name="location" id="location" class="select2" required="">
                          <option value="">Please Choose District</option>
                        </select>
                      </div>					   
					   
				                  <div class="col-md-4 top15">
		                    <span class="badge-label info-color p-2">Client Image<span class="redstar">*</span></span><br/>
		                    <input  type="file" name="client_image" style="margin-top: 10px;" />
		                  </div>			   
					   
		
					   
					  <div class="col-md-4 top15">
		                    <span class="badge-label info-color p-2">Remarks<span class="redstar">*</span></span>
		                    <input type="text" id="remarks" name="remarks" class="form-control" placeholder="Remarks" value="" required="">
		              </div>
					  
					  
					  					    <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Type<span class="redstar">*</span></span>

                        <select name="vehicletype" id="vehicletype" class="select2" required="">
                          <option value="">Please Choose Vehicle Type</option>
                          <option value="car">Car</option>
                          <option value="bike">Bike</option>
                        </select>
                      </div>
					  
					  
					    <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Brand<span class="redstar">*</span></span>

                        <select name="vehiclebrand" id="vehiclebrand" class="select2" required="">
                          <option value="">Please Choose Vehicle Brand</option>
                          <option value="Hero">Hero</option>
                        </select>
                      </div>
					  
					  					    <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Model<span class="redstar">*</span></span>

                        <select name="vehiclemodel" id="vehiclemodel" class="select2" required="">
                          <option value="">Please Choose Vehicle Model </option>
                          <option value="2021">2021</option>
                        </select>
                      </div>
					  
					  			  					    <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Year<span class="redstar">*</span></span>

                        <select name="vehicleyear" id="vehicleyear" class="select2" required="">
                          <option value="">Please Choose Vehicle Year</option>
                          <option value="M1999">M1999</option>
                        </select>
                      </div>
					  
					  					  			  					    <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Varient <span class="redstar">*</span></span>

                        <select name="vehiclevarient" id="vehiclevarient" class="select2" required="">
                          <option value="">Please Choose Vehicle Varient </option>
                          <option value="Red">Red</option>
                        </select>
                      </div>
					  
					  
					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2">Vehicle Remarks  <span class="redstar">*</span></span>
						
								                    <input type="text" id="vehicleremarks" name="vehicleremarks" class="form-control" placeholder="Vehicle Remarks" value="" required="">


                      </div>
					   
					   					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	Vehicle Checklist ID  <span class="redstar">*</span></span>

                        <select name="vehiclechecklist_id" id="vehiclechecklist_id" class="select2" required="">
                          <option value="">Please Choose Vehicle Checklist</option>
                          <option value="10001">10001</option>
                        </select>
                      </div>
					   
		
		<div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	Vehicle Damage Report ID<span class="redstar">*</span></span>

                        <select name="vehicledamage_reportid" id="vehicledamage_reportid" class="select2" required="">
                          <option value="">Please Choose Vehicle Damage Reportid</option>
                          <option value="R0001">R0001</option>
                        </select>
                      </div>


					  <div class="col-md-4 top15">
                        <span class="badge-label info-color p-2"> 	 	Vehicle Inspection Report ID<span class="redstar">*</span></span>

        <select name="vehicleinspectionreportid" id="vehicleinspection_reportid" class="select2" required="">
                          <option value="">Please Choose  	Vehicle Inspection Report ID</option>
                          <option value="Ine001">Ine001</option>
                        </select>
                      </div>
					   	                
						<div class="col-md-4 pull-right" style="padding-top:5px;">
		                    <button type="submit" name="create" class="btn btn-primary btn-circle btn-lg"><i class="fa fa-check" aria-hidden="true"></i></button>
		                    <button type="reset" name="reset" class="btn btn-warning btn-circle btn-lg"><i class="fa fa-times" aria-hidden="true"></i></button>
		                  </div>

		                </form>


		              </div>
		            </div>
		        </div>
		        <!-- table -->
		        <div class="row">
	                <div class="panel-default">
	                  <div class="panel-body">
	                    <table id="client_table" class="table table-striped table-hover" width="100%">
	                      <thead>
	                        <tr>
	                          <th>ID</th>   
	                          <th>Name</th>
	                          <th>Mobile</th>                          
	                          <th>Alternate Mobile</th>                          
	                          <th>State</th>                          
	                          <th>District</th>                          
	                          <th>City</th>                          
	                          <th>Client Image</th>                          
	                          <th>Remarks</th>                          
	                          <th>Vehicle Brand</th>                          
	                          <th>Vehicle Model</th>                          
	                          <th>Vehicle Year</th>                          
	                          <th>Vehicle Varient</th>                          
	                          <th>Vehicle Remarks</th>                          
	                          <th>Checklist ID</th>                          
	                          <th>Damage Report ID</th>                          
	                          <th>Inspection Report ID</th>                          
	                          <th class="sp_view">View</th>
	                          <th class="sp_edit">Edit</th>
	                          <th class="sp_delete">Delete</th>	                          
	                        </tr>
	                      </thead>
	                      <tbody>                       
	                      </tbody>
	                    </table>
	                  </div>
	                </div>
	            </div>
	    	</div>
	    	<!-- table -->
		</div>	    
	</div>
</div>


    <!-- Modal -->
<div class="modal fade sp_edit" id="edit_client_model" role="dialog">
  <div class="modal-dialog cascading-modal modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header light-blue darken-3 white-text">
          <button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
          <h4 class="title"><i class="fa fa-pencil-alt"></i> EDIT</h4>
      </div>
      <div class="modal-body mb-0">
        <form id="edit_client_form" method="post" enctype="multipart/form-data">
          <div style="margin-bottom: 15px" ><div class="row" id="edit_details"></div></div>
          <div class="text-center">
            <button type="submit" name="update"  class=" btn btn-success button-update btnModalEdit"><i class="fa fa-check" aria-hidden="true"></i>Update</button>
            <button type="button" data-dismiss="modal" class="btn btn-warning button-cancel"><i class="fa fa-times"></i>Cancel</button>
          </div>
          <br/>
        </form>
       </div>
    </div>
  </div>
</div>
<?php include 'inc-script.php'; ?>
<script type="text/javascript">
    function newexportaction(e, dt, button, config) {
         var self = this;
         var oldStart = dt.settings()[0]._iDisplayStart;
         dt.one('preXhr', function (e, s, data) {
             // Just this once, load all data from the server...
             data.start = 0;
             data.length = 2147483647;
             dt.one('preDraw', function (e, settings) {
                 // Call the original action function
                 if (button[0].className.indexOf('buttons-copy') >= 0) {
                     $.fn.dataTable.ext.buttons.copyHtml5.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-excel') >= 0) {
                     $.fn.dataTable.ext.buttons.excelHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.excelHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.excelFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-csv') >= 0) {
                     $.fn.dataTable.ext.buttons.csvHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.csvHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.csvFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-pdf') >= 0) {
                     $.fn.dataTable.ext.buttons.pdfHtml5.available(dt, config) ?
                         $.fn.dataTable.ext.buttons.pdfHtml5.action.call(self, e, dt, button, config) :
                         $.fn.dataTable.ext.buttons.pdfFlash.action.call(self, e, dt, button, config);
                 } else if (button[0].className.indexOf('buttons-print') >= 0) {
                     $.fn.dataTable.ext.buttons.print.action(e, dt, button, config);
                 }
                 dt.one('preXhr', function (e, s, data) {
                     // DataTables thinks the first item displayed is index 0, but we're not drawing that.
                     // Set the property to what it was before exporting.
                     settings._iDisplayStart = oldStart;
                     data.start = oldStart;
                 });
                 // Reload the grid with the original page. Otherwise, API functions like table.cell(this) don't work properly.
                 setTimeout(dt.ajax.reload, 0);
                 // Prevent rendering of the full data to the DOM
                 return false;
             });
         });
         // Requery the server with the new one-time export settings
         dt.ajax.reload();
     }

  window.addEventListener('load', function(){
  $('#client_table').dataTable({
    "destroy": true,
    "retrieve": true,
    "responsive": true,
    "ordering": true,
    "searching": true,
    "sDom":"tpr",
    "lengthChange": true,
    "lengthMenu": [[25, 50, 100, 500, 1000],[25, 50, 100, 500, 1000]],
    "pageLength": 100,
    "processing": true,
    "serverSide": true,
    "bAutoWidth": false,
    "ajax": "ajax_table_load.php?action=client_table",
    dom: 'Bldfrtip',
    "stateSave": true,
        buttons: [{
            "extend": 'excel',
            "text": '<i class="fa fa-file-excel-o" style="color: green;"></i>  Excel',
            "titleAttr": 'Excel',
            "action": newexportaction
        },
        {
            extend: 'colvis',            
            text: "<i class='fa fa-table''></i> Customize Grid",
            postfixButtons: [ 'colvisRestore' ],
            collectionLayout: 'fixed two-column',
            'colVis': {
                'buttonText': 'Toon / verberg kolommen',
                'overlayFade': 0,
                'exclude': [ 0 ],
            },
        }
        ]
  });
});

$(document).on('click', '.btnTableEdit', function( event ) {
    event.preventDefault();
    var value = $(this).attr('data-id');
    $.ajax({
        url: 'ajax_load.php',
        type: 'POST',
        data: 'action=edit_client&id='+value,
        dataType: 'html'
    })
    .done(function(data){
       $('#edit_details').empty().append(data); 

$("#state1, #location1, #district1, #vehiclebrand, #vehiclemodel, #vehicleyear, #vehiclevarient,  #vehiclechecklist_id, #vehicledamage_reportid, #vehicleinspection_reportid").select2({
  tags: true
});
	   
    })
    $('#myModal').modal('show');
    return false;
});

$("#state, #location, #district, #vehicletype, #vehiclebrand, #vehiclemodel, #vehicleyear, #vehiclevarient,  #vehiclechecklist_id, #vehicledamage_reportid, #vehicleinspection_reportid").select2({
  tags: true
});

/*
$(document).on('change','select[name=vehicletype]',function(){
  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_vehicletype&vehicletype='+$(this).val(),
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=vehiclebrand]").html(data["Data"]);
  }
  else{
    $("select[name=vehiclebrand]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});

$(document).on('change','select[name=vehiclebrand]',function(){
	
	var vehicletype = $('#vehicletype').val();
  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_vehiclebrand&vehiclebrand='+$(this).val()+'&vehicletype='+vehicletype,
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=vehiclemodel]").html(data["Data"]);
  }
  else{
    $("select[name=vehiclemodel]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});


$(document).on('change','select[name=vehiclemodel]',function(){
	
	var vehicletype = $('#vehicletype').val();
  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_vehiclemodel&vehiclemodel='+$(this).val()+'&vehicletype='+vehicletype,
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=vehicleyear]").html(data["Data"]);
  }
  else{
    $("select[name=vehicleyear]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});


$(document).on('change','select[name=vehicleyear]',function(){
	
	var vehicletype = $('#vehicletype').val();
  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_vehicleyear&vehicleyear='+$(this).val()+'&vehicletype='+vehicletype,
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=vehiclevarient]").html(data["Data"]);
  }
  else{
    $("select[name=vehiclevarient]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});
*/

$(document).on('change','select[name=state]',function(){
  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_district&state='+$(this).val(),
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=district]").html(data["Data"]);
  }
  else{
    $("select[name=district]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});

$(document).on('change','select[name=district]',function(){
  var state = $(this).parent().parent().find($("select[name=state]")).val();
  var district = $(this).val();

  $.ajax({
    type: 'POST',
    url: 'ajax_load.php',
    data: 'action=get_location&district='+district+'&state='+state,
    dataType: "json",
    success: function(data){ 
    if(data['status'] == 'success'){ 
      $("select[name=location]").html(data["Data"]);
  }
  else{
    $("select[name=location]").html("<option value=''>No Data Found</option>");
    }
  },
  error: function(jqXHR, textStatus, errorThrown) {
    error_alertbox('','');
  }
  });
});


$(document).ready(function(e){
    $("#client_add").on('submit', function(e){
        e.preventDefault();
		
		var formData = new FormData(this);
		formData.append('action', 'insert_client');
        $.ajax({
            type: 'POST',
            url: 'ajax.php',
            data: formData,
            contentType: false,
            cache: false,
            processData:false, 
            dataType: "json",
            success: function(data){ 
			
	        if(data['status'] == 'success'){ 
          		success_alertbox('','Insert');
	        }
	        else{
          		error_alertbox('','Insert');
	          }
		  
            },		
	        error: function(jqXHR, textStatus, errorThrown) {
          	error_alertbox('','');
	           
	        }
   		})
	});
    $("#edit_client_form").on('submit', function(e){
        e.preventDefault();
		var formData = new FormData(this);
		formData.append('action', 'update_client');
        $.ajax({
            type: 'POST',
            url: 'ajax.php',
            data: formData,
            contentType: false,
            cache: false,
            processData:false, 
            dataType: "json",
            success: function(data){ 
            if(data['status'] == 'success'){ 
          		success_alertbox('','Update');
	        }
	        else{
          		error_alertbox('','Update');
	          }
            },
	        error: function(jqXHR, textStatus, errorThrown) {
          	error_alertbox('','');
	           
	        }
    })
});
});
</script>
</body>
</html>